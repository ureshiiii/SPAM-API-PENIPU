# Instalasi

Clone repository ini, lalu jalankan command `npm install`.

# Execution

Jalankan program dengan command node `app.js`

# Fitur

- Counter attack (sp4m) API telegram
- Bikin list API telegram yang mau dijadikan target dalam file `.txt`
- Send request ke multiple API secara bersamaan.
